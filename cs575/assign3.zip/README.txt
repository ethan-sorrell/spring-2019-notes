CS-575 Programming Project by Ethan Sorrell

Included are several example input files and an example test script test.sh
This project may be compiled by
javac bpcp/Main.java
Then the program may be executed by
java bpcp/Main $INPUT_FILE$
where $INPUT_FILE$ is the desired input file.
Alternatively, the provided test.sh file may be examined to see the format of these commands.

The format of input files is expected to follow the format:
Bounded depth on the first line
Following lines contain [PART1,PART2] with PART1 and PART2 constituting the pair of strings for that rule
