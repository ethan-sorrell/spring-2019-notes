#!/bin/bash
javac bpcp/Main.java
java bpcp/Main input.txt

