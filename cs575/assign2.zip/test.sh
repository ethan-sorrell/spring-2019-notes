#!/bin/bash
javac bottomup/Main.java
java bottomup/Main input2.xml
