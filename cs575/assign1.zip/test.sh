#!/bin/bash
javac topdown/Main.java
java topdown/Main test.xml

