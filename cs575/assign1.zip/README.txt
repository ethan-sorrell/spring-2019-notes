CS-575 Programming Project by Ethan Sorrell

Included are several example input files and an example test script test.sh
This project may be compiled by
javac topdown/Main.java
Then the program may be executed by
java topdown/Main $INPUT_FILE$
where $INPUT_FILE$ is the desired input file.
Alternatively, the provided test.sh file may be examined to see the format of these commands.
